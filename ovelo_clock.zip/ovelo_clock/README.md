# ovelo_clock

Welcome to Ovelo Clock!

This is a themeable clock UI for submission to flutter clock challenge  [flutter.dev/clock](https://flutter.dev/clock).
